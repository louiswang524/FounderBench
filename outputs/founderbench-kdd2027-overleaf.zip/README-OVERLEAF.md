﻿# FounderBench KDD 2027 — Overleaf package

## Compile
1. Set Overleaf compiler to **pdfLaTeX** (or TeX Live 2024+).
2. Main document: `main.tex`.
3. Menu → Compiler → enable **BibTeX** if needed (`main.bbl` is included as a fallback).
4. Optional supplementary: compile `appendix.tex` separately (or upload as a second project / supplementary PDF).

## Contents
- `main.tex` — ACM sigconf manuscript
- `appendix.tex` — supplementary appendix
- `table-*.tex` — generated tables
- `figures/*.pdf` — publication figures
- `founderbench-references.bib` — bibliography
- `main.bbl` — precomputed BibTeX output

Requires the ACM `acmart` class (available on Overleaf by default).
