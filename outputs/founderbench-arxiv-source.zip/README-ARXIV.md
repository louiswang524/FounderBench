# FounderBench arXiv package

Title: FounderBench: Evaluating LLM Agents on Sequential Startup Decisions
Author: Yufeng Wang <louiswang524@gmail.com>

## KDD policy (Datasets & Benchmarks)

arXiv preprints are allowed for KDD submissions. Sister KDD tracks explicitly state that work already on arXiv/SSRN may be submitted. D&B is **single-blind**, so a named preprint is fine. Still double-check the live CFP before upload: https://kdd2027.kdd.org/datasets-and-benchmarks-track-call-for-papers/

## What to upload to arXiv

**Recommended:** upload the PDF (`founderbench-arxiv.pdf`) *or* this TeX source zip.

### Suggested arXiv metadata
- **Title:** FounderBench: Evaluating LLM Agents on Sequential Startup Decisions
- **Authors:** Yufeng Wang
- **Primary category:** cs.AI (or cs.LG)
- **Cross-lists (optional):** cs.CL, cs.MA
- **Comments:** Preprint. Under review at ACM KDD 2027 Datasets & Benchmarks Track. 7 content pages + appendix appendix.
- **License:** Choose an arXiv-compatible license you are comfortable with (e.g., CC BY 4.0 or arXiv perpetual non-exclusive).

### Compile (if uploading source)
```
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```
Main file: `main.tex` (appendix included).

## Differences from the KDD review PDF
- No `review` line numbers
- Named author block
- Short preprint banner under the title
- Affiliation city filled (San Francisco) to silence acmart warnings — edit if wrong
