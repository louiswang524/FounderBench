# FounderBench — KDD Datasets & Benchmarks (single-blind)

Track: **Datasets & Benchmarks** (single-blind; author names listed)
Author: Yufeng Wang <louiswang524@gmail.com>
Class: `\documentclass[sigconf,review]{acmart}`

## Compile
1. Main document: `main.tex`
2. Compiler: pdfLaTeX + BibTeX
3. Single PDF: content + references + appendix

## Note
Affiliation is set to "Independent Researcher". Edit `main.tex` if you want a university/company affiliation.
