# FounderBench — Anonymous Overleaf package (double-blind)

Prepared for KDD-style **double-blind** review:
`\documentclass[sigconf,anonymous,review]{acmart}`

## Important track note
- **KDD Research Track**: double-blind → use this package.
- **KDD Datasets & Benchmarks Track**: currently **single-blind** (author names should be listed). Do **not** use this anonymous package for D&B unless the CFP changes.

## Compile
1. Main document: `main.tex`
2. Compiler: pdfLaTeX + BibTeX
3. Produces a **single PDF**: content + references + optional appendix
4. `main.bbl` is included as a BibTeX fallback

## Anonymity checklist applied
- `anonymous,review` class options
- Author names/affiliations suppressed
- No acknowledgments
- No public repository URL
- Release language softened to “upon acceptance” / supplementary artifact
- Appendix merged after references (KDD single-PDF requirement)
